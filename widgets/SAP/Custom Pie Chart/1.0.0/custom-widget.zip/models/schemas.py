from pydantic import BaseModel
from typing import Optional, List

class Installation(BaseModel):
    id: int
    account: dict
    repository_selection: str
    permissions: dict
    events: List[str]

class WebhookEvent(BaseModel):
    action: str
    installation: Installation
    repository: dict

class AppConfig(BaseModel):
    app_id: int
    private_key: str
    webhook_secret: str
    base_url: str
    redirect_url: str